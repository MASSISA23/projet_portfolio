package com.rhsaas.authentication;

public class Session {
    
}
