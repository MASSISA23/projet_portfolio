package com.rhsaas.authentication;

public class Log {
    
}
