package com.rhsaas.utils;

public enum Gender {
    HOMME,
    FEMME,
    NON_BINAIRE,
    TRANSGENRE,
    AUTRES
}