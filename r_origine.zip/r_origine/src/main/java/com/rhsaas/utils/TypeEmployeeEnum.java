package com.rhsaas.utils;

public enum TypeEmployeeEnum {
    PLEIN_TEMPS,
    PARTIEL,
    CONTRACTUEL,
    FREELANCE,
    CONSULTANT,
    STAGIAIRE,
    RESPONSABLE,
    CADRE_SUPERIEUR,
    TELETRAVAILLEUR
}