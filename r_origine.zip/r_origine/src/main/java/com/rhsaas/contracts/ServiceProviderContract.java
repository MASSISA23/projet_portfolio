package com.rhsaas.contracts;

public class ServiceProviderContract {
    
}
