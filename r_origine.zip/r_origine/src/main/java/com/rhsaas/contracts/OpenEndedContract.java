package com.rhsaas.contracts;

public class OpenEndedContract {
    
}
