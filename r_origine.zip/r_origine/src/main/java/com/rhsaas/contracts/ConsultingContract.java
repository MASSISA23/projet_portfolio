package com.rhsaas.contracts;

public class ConsultingContract {
    
}
