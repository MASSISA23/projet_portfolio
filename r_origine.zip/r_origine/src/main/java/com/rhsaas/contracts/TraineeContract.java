package com.rhsaas.contracts;

public class TraineeContract {
    
}
